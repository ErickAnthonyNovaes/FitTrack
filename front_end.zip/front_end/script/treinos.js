document.addEventListener("DOMContentLoaded", function () {
    const usuarioId = localStorage.getItem("usuarioId");

    if (!usuarioId) {
        window.location.href = "index.html"; // Redireciona para login se não estiver logado
        return;
    }

    carregarTreinos();

    // Evento de logout
    document.getElementById("logout").addEventListener("click", function () {
        localStorage.removeItem("usuarioId");
        window.location.href = "index.html"; 
    });

    // Adicionar treino ao submeter o formulário
    document.getElementById("form-treinos").addEventListener("submit", adicionarTreino);
});

const usuario = JSON.parse(localStorage.getItem("usuario"));

    if (usuario && usuario.nome) {
        // Atualiza o texto da navbar com o nome do usuário
        document.getElementById("usuarioNome").textContent = `Olá, ${usuario.nome}.`;
    }

// Função para carregar os treinos do usuário
async function carregarTreinos() {
    const usuarioId = localStorage.getItem("usuarioId");

    try {
        const resposta = await fetch(`http://localhost:5083/api/exercicios/${usuarioId}`);
        if (!resposta.ok) throw new Error("Erro ao carregar treinos");

        const treinos = await resposta.json();
        const tabelaTreinos = document.getElementById("listaTreinos");
        tabelaTreinos.innerHTML = ""; // Limpa a tabela

        if (treinos.length === 0) {
            tabelaTreinos.innerHTML = `<tr><td colspan="5" class="text-center">Nenhum treino registrado.</td></tr>`;
            return;
        }

        treinos.forEach(treino => {
            const linha = document.createElement("tr");
            linha.innerHTML = `
                <td>${treino.nome}</td>
                <td>${treino.peso} kg</td>
                <td>${treino.repeticoes}</td>
                <td>${new Date(treino.data).toLocaleDateString()}</td>
                <td><button class="btn btn-danger btn-remover" data-id="${treino.id}">Remover</button></td>
            `;
            tabelaTreinos.appendChild(linha);
        });

        // Adiciona evento de clique nos botões "Remover"
        document.querySelectorAll(".btn-remover").forEach(botao => {
            botao.addEventListener("click", function () {
                const treinoId = this.getAttribute("data-id");
                removerTreino(treinoId);
            });
        });

    } catch (error) {
        console.error("Erro ao carregar treinos:", error);
    }
}

// Função para adicionar um novo treino
async function adicionarTreino(event) {
    event.preventDefault();
    
    const usuarioId = localStorage.getItem("usuarioId");
    const nome = document.getElementById("exercicio").value.trim();
    const peso = document.getElementById("peso").value.trim();
    const repeticoes = document.getElementById("repeticoes").value.trim();
    const data = document.getElementById("data").value.trim();

    if (!nome || !peso || !repeticoes || !data) {
        alert("Preencha todos os campos!");
        return;
    }

    const novoTreino = {
        usuarioId: usuarioId,
        nome: nome,
        peso: parseFloat(peso),
        repeticoes: parseInt(repeticoes),
        data: data
    };

    try {
        const resposta = await fetch("http://localhost:5083/api/exercicios", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(novoTreino)
        });

        if (!resposta.ok) throw new Error("Erro ao adicionar treino");

        carregarTreinos(); // Recarrega a lista de treinos
        document.getElementById("form-treinos").reset(); // Limpa o formulário

    } catch (error) {
        console.error("Erro ao adicionar treino:", error);
    }
}

// Função para remover um treino
async function removerTreino(id) {
    try {
        const resposta = await fetch(`http://localhost:5083/api/exercicios/${id}`, { method: "DELETE" });

        if (!resposta.ok) throw new Error("Erro ao remover treino");

        location.reload(); // Recarrega a página após a remoção

    } catch (error) {
        console.error("Erro ao remover treino:", error);
    }
}
