document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("btnLogin").addEventListener("click", fazerLogin);
});

async function fazerLogin() {
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value.trim();

    if (email === "" || senha === "") {
        alert("Por favor, preencha todos os campos!");
        return;
    }

    try {
        const url = `http://localhost:5083/api/usuario/login?email=${encodeURIComponent(email)}&senha=${encodeURIComponent(senha)}`;

        const response = await fetch(url, { method: "GET" });

        // Verifica se a resposta da API é válida
        if (!response.ok) {
            throw new Error("Erro na requisição da API");
        }

        const data = await response.json();

        // Exibe a resposta no console para debug
        console.log("Resposta da API:", data);

        // Verifica se a API retornou um usuário válido
        if (data.usuario && data.usuario.id) {
            localStorage.setItem("usuarioId", data.usuario.id);
            localStorage.setItem("usuario", JSON.stringify(data.usuario));
            window.location.href = "home.html";
        } else {
            alert("Email ou senha incorretos!");
            console.log("Dados inválidos recebidos:", data);
        }

    } catch (error) {
        alert("Erro ao tentar fazer login.");
        console.error("Erro:", error);
    }
}
