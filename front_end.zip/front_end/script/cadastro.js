document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("btnCadastrar")?.addEventListener("click", async function(event) {
        event.preventDefault();
        await cadastrarUsuario();
    });
});

async function cadastrarUsuario() {
    const nome = document.getElementById("users")?.value?.trim();  // Corrigido para 'users'
    const email = document.getElementById("email")?.value?.trim();
    const senha = document.getElementById("senha")?.value?.trim();

    if (nome && email && senha) {
        const usuario = { nome, email, senha };

        try {
            const response = await fetch("http://localhost:5083/api/usuario/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(usuario)
            });

            const data = await response.json();
            if (response.ok) {
                alert(data.message || "Cadastro realizado com sucesso! Redirecionando...");
                window.location.href = "index.html"; // Redireciona para a página de login
            } else {
                alert(data.message || "Erro ao cadastrar usuário.");
            }
        } catch (error) {
            console.error("Erro ao conectar com a API:", error);
            alert("Erro ao tentar cadastrar. Tente novamente.");
        }
    } else {
        alert("Por favor, preencha todos os campos!");
    }
}
